ENROLMENT MODULES
-----------------

(Yes, that's the correct English spelling  ;-) )

All enrolment modules must extend base class enrol_plugin
which is defined in lib/enrollib.php. You can find documentation
of each method in the base class.

